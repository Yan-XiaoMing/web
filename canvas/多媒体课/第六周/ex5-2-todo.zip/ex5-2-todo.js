
var legend=["优秀","良好","中等","及格","不及格"];
var data=[20,40,20,10,10];
var colors=["#1a9641","#a6d96a","#fdae61","#fda9a3","#d7191c"];

var RECT_MARGIN=15,
	TEXT_OFFSET=50,
	PIE_OFFSET=50,
	LINE_OFFSET=8,
	START_ANGLE=-Math.PI/3;

//函数自定义区





//事件处理函数定义




//调用执行

