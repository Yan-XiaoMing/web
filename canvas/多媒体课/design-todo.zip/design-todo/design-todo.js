/*
	Functions：期末上机考设计题
	Author：zjvivi
	Build-date：2019-12-22
	Version：1.0
*/
// 1、变量定义

var image=new Image();


var PIE_OFFSET=50,    //控制饼图偏移
	START_ANGLE=-Math.PI/3;   //饼图第一块的初始弧度

var RECT_COLOR="rgba(255,255,255,0.35)";  //矩形框颜色

//2、函数自定义区


//3、事件处理函数定义


//4、调用执行

//初始设定
style.fontSize=20;
circle.x+=PIE_OFFSET;
line.x0=circle.x;


rect.x=10;
rect.y=10;
rect.width=canvas.width-20;
rect.height=canvas.height-20;

text.x=100;
text.y=canvas.height/2;	
style.hAlign="left";
style.vAlign="top";


 