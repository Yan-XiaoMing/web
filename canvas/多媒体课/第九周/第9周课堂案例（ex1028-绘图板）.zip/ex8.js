/*
	Functions  :ex8 绘图板
	Author    :zjvivi
	Build_Date:2019-10-28
	Version   :1.0
 */

//1. 公共变量声明块........................................................

var canvas=document.getElementById("canvas"),
	ctx=canvas.getContext("2d");
//新建离屏canvas
var offscreenCanvas=document.createElement("canvas"),  //新建canvas元素
	offscreenCtx=offscreenCanvas.getContext("2d");     //获取新建canvas的绘图环境
//设置离屏大小
	offscreenCanvas.width=canvas.width;
	offscreenCanvas.height=canvas.height;  
	

var ctxTips=[];
var canvasArrs=[];
	
var iCanvasWidth=canvas.width,
	iCanvasHeight=canvas.height;

var startPoint={x:0,y:0},
	midPoint={x:0,y:0},
	endPoint={x:0,y:0};

var flag=false;

var TIPS_NUM=4,   //设置工具栏工具个数
	COLORS_NUM=12;   //设置颜色块数

var shape=0;  //获取绘制的形状
//2. 函数定义块...........................................................
//生成形状工具栏
function appendToolbars(){
	var divTips=document.getElementById("tips");  //获取id=tips的div
	var elem="";  //初始化
	
	//生成canvas图标的HTML字符串
	for(i=0;i<TIPS_NUM;i++){
		elem += "<canvas width='30' height='30' class='canvas_tips'></canvas>";
	}
	//赋值给id=tips的div内部，从而会显示canvas图标
	divTips.innerHTML=elem;
	
	//获取canvas元素标记对象
	canvasArrs=document.getElementsByTagName("canvas"); 
	//设置图标绘制形状的颜色
	style.color="#000";
	//设置绘制rect的大小和起始点坐标
	rect.width=canvasArrs[0].width/2;
	rect.height=canvasArrs[0].width/3;
	rect.x=canvasArrs[0].width/2-rect.width/2;
	rect.y=canvasArrs[0].height/2-rect.height/2;

	//遍历获取canvas图标对象，并绘制相应的图标形状
	for(index in canvasArrs){
		if(index<canvasArrs){
			ctxTips[index]=canvasArrs[index].getContext('2d');
			
		}
		switch(index){
			//曲线图标
			case "0":
				//绘制曲线图标
				ctxTips[index].beginPath();
				ctxTips[index].moveTo(5,5);
				curve.x0=25;
				curve.y0=8;
				curve.x1=15;
				curve.y1=10;
				drawCurve(ctxTips[index],curve,style,0);
			
				curve.x0=5;
				curve.y0=15;
				curve.x1=10;
				curve.y1=18;
				drawCurve(ctxTips[index],curve,style,0);

				curve.x0=10;
				curve.y0=25;
				curve.x1=15;
				curve.y1=18;
				drawCurve(ctxTips[index],curve,style,1);
				//注册曲线图标mousedown事件
				canvasArrs[index].addEventListener("mousedown",onCanvasTipsMousedown);
				//默认为曲线图标被选中ß
				canvasArrs[index].style.backgroundColor="#ffc";
				break;
			//实心矩形
			case "1":
				drawRect(ctxTips[index],rect,style,1);
				canvasArrs[index].addEventListener("mousedown",onCanvasTipsMousedown);
				break;
			//空心矩形
			case "2":
				drawRect(ctxTips[index],rect,style,0);
				canvasArrs[index].addEventListener("mousedown",onCanvasTipsMousedown);
				break;
			//文本
			case "3":
				//设置文本对象text的相关属性
				text.text="T";
				text.x=canvasArrs[index].width/2;
				text.y=canvasArrs[index].height/2;
				style.hAlign="center";
				style.vAlign="middle";
				style.fontSize="14";
				//绘制文本
				drawText(ctxTips[index],text,style,1);
				canvasArrs[index].addEventListener("mousedown",onCanvasTipsMousedown);
		}
		
	}
		
}

//设置颜色块
function setColors(){
	//获取li元素
	var lis=document.getElementsByTagName("li");
	for(i in lis){
		//设置随机色
		r=parseInt(Math.random()*254);
		g=parseInt(Math.random()*254);
		b=parseInt(Math.random()*254);
		color="rgb("+r+","+g+","+b+")";
		//显示随机色
		if(i<COLORS_NUM) lis[i].style.backgroundColor=color;
		//显示白色
		if(i==COLORS_NUM) {
			lis[i].style.backgroundColor="#fff";
		}
		//颜色块注册单击事件
		lis[i].onclick=onLiClick;
	}
}



//3. 事件注册块...........................................................
// 鼠标移动事件处理
function onCanvasMouseMove(event){
	if(flag){
		endPoint.x=event.clientX;
		endPoint.y=event.clientY;
		endPoint=windowToCanvas(canvas,endPoint);


		// 0、曲线绘制
		if(shape==0){
			//实时计算曲线控制点位置，控制在起点和终止点一半的位置（这个可自定）
			var cpx=midPoint.x<endPoint.x?midPoint.x+(endPoint.x-midPoint.x)/2 : endPoint.x+(midPoint.x-endPoint.x)/2;
			var cpy=midPoint.y<endPoint.y?midPoint.y+(endPoint.y-midPoint.y)/2 : endPoint.y+(midPoint.y-endPoint.y)/2;
			//实时计算绘制曲线需要的控制点坐标和终止点坐标
			curve.x0=cpx;
			curve.y0=cpy;
			curve.x1=endPoint.x;
			curve.y1=endPoint.y;
			//绘制曲线
			drawCurve(ctx,curve,style,1);
			//当前终止点为下一段曲线的起始点
			for(index in endPoint){
				midPoint[index]=endPoint[index];
			}
		}

		// 1、实心矩形绘制
		if(shape==1){
			//ctx.clearRect(0, 0, iCanvasWidth, iCanvasHeight);
			//矩形的起始点设置
			rect.x=startPoint.x;
			rect.y=startPoint.y;
			//实时计算矩形宽度和高度
			rect.width=endPoint.x-startPoint.x;
			rect.height=endPoint.y-startPoint.y;
			ctx.beginPath();
			drawRect(ctx,rect,style,1);
		}
		
		// 2、空心矩形绘制
		if(shape==2){
					
			if(rect.x<endPoint.x && rect.y<endPoint.y) 
				ctx.clearRect(rect.x-1, rect.y-1, rect.width+2, rect.height+2);
			else
				ctx.clearRect(rect.x+1, rect.y+1, rect.width+2, rect.height+2);
			rect.x=startPoint.x;
			rect.y=startPoint.y;
			
			rect.width=endPoint.x-startPoint.x;
			rect.height=endPoint.y-startPoint.y;
			//清空
			ctx.clearRect(0,0,canvas.width,canvas.height);
			//绘制mousedown中备份的离屏内容
			ctx.drawImage(offscreenCanvas,0,0,canvas.width,canvas.height);
			//绘制当前矩形
			ctx.beginPath();
			drawRect(ctx,rect,style,0);
		}
		
		
	}
}
// 鼠标按下事件处理
function onCanvasMouseDown(event){
	startPoint.x=event.clientX;
	startPoint.y=event.clientY;
	startPoint=windowToCanvas(canvas,startPoint);
	//曲线绘制处理
	if(shape==0){
		ctx.beginPath();
		ctx.moveTo(startPoint.x, startPoint.y);
		// 曲线绘制
		for(index in startPoint){
			midPoint[index]=startPoint[index];
		}
	}
	//空心矩形，则离屏备份
	if(shape==2) offscreenCtx.drawImage(canvas,0,0,canvas.width,canvas.height);
	//mousemove是否处理的标志
	flag=true;

	
}
// 鼠标抬起事件处理
function onCanvasMouseUp(event){
	flag=false;
}

// 无符号列表ul下的元素li的单击事件处理
function onLiClick(event){
	// this表示触发click事件的对象

	if(this.style.backgroundColor!="rgb(255, 255, 255)") 
		style.color=this.style.backgroundColor;
	else{
		ctx.clearRect(0, 0, iCanvasWidth, iCanvasHeight);
	}

}
//图标canvas的mousedown事件处理
function onCanvasTipsMousedown(event){
	for(i in canvasArrs){
		//循环遍历对象若为当前图标canvas
		if(canvasArrs[i]===event.target){
			this.style.backgroundColor="#ffc";  //设置当前选中图标的背景色
			shape=i;  //设置形状shape的值，在绘图板canvas的mousedown事件中用于判断绘制形状
		}

		else{
			//非当前对象背景色还原为白色
			if(i<TIPS_NUM) canvasArrs[i].style.backgroundColor="#fff";
		}
	}
	
}

// 事件注册
canvas.addEventListener("mousedown",onCanvasMouseDown);
canvas.addEventListener("mousemove",onCanvasMouseMove);
canvas.addEventListener("mouseup",onCanvasMouseUp);

//4. 初始化块............................................................
//加canvas图标工具栏
appendToolbars();
//设置颜色块
setColors();



// windowToCanvas(canvas);