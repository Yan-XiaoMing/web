# BB_BOMB
A small flight shooting game based on HTML5 Canvas.

### Tutorial

W S A D to move.

Mouse to shot.

Space to shot super laser.

### Screen Shots

![](screen_shots/20161230163217.jpg)

![](screen_shots/20161230163239.jpg)
